import express from 'express';
import path from 'path';
import { google } from 'googleapis';
import { createServer as createViteServer } from 'vite';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '10mb' }));

  // Helper to construct Google Auth Client
  const getGoogleAuth = () => {
    return new google.auth.GoogleAuth({
      scopes: [
        'https://www.googleapis.com/auth/spreadsheets',
        'https://www.googleapis.com/auth/drive.file',
      ],
    });
  };

  // --- API ROUTES ---

  // Health check
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
  });

  /**
   * Create a new Google Sheet for Inventory Management
   */
  app.post('/api/sheets/create', async (req, res) => {
    try {
      const auth = getGoogleAuth();
      const sheets = google.sheets({ version: 'v4', auth });

      const { title = 'Quản Lý Nhập Xuất Tồn Kho' } = req.body;

      // Create spreadsheet
      const response = await sheets.spreadsheets.create({
        requestBody: {
          properties: {
            title: `${title} - ${new Date().toLocaleDateString('vi-VN')}`,
          },
          sheets: [
            {
              properties: { title: 'DANH_MUC_KHO' },
              data: [
                {
                  rowData: [
                    {
                      values: [
                        { userEnteredValue: { stringValue: 'Mã Kho (*)' } },
                        { userEnteredValue: { stringValue: 'Tên Kho (*)' } },
                        { userEnteredValue: { stringValue: 'Địa Chỉ / Địa Điểm' } },
                        { userEnteredValue: { stringValue: 'Người Quản Lý' } },
                        { userEnteredValue: { stringValue: 'Số Điện Thoại' } },
                      ],
                    },
                  ],
                },
              ],
            },
            {
              properties: { title: 'DANH_MUC_SAN_PHAM' },
              data: [
                {
                  rowData: [
                    {
                      values: [
                        { userEnteredValue: { stringValue: 'Mã Sản Phẩm (*)' } },
                        { userEnteredValue: { stringValue: 'Tên Sản Phẩm (*)' } },
                        { userEnteredValue: { stringValue: 'Đơn Vị Tính (*)' } },
                        { userEnteredValue: { stringValue: 'Nhóm Hàng' } },
                        { userEnteredValue: { stringValue: 'Tồn Tối Thiểu' } },
                        { userEnteredValue: { stringValue: 'Giá Nhập Tham Chiếu' } },
                        { userEnteredValue: { stringValue: 'Giá Xuất Tham Chiếu' } },
                        { userEnteredValue: { stringValue: 'Mô Tả' } },
                      ],
                    },
                  ],
                },
              ],
            },
            {
              properties: { title: 'NHAP_XUAT_KHO' },
              data: [
                {
                  rowData: [
                    {
                      values: [
                        { userEnteredValue: { stringValue: 'Mã Phiếu' } },
                        { userEnteredValue: { stringValue: 'Loại Phiếu (Nhập/Xuất)' } },
                        { userEnteredValue: { stringValue: 'Ngày (YYYY-MM-DD)' } },
                        { userEnteredValue: { stringValue: 'Mã Kho' } },
                        { userEnteredValue: { stringValue: 'Tên Kho' } },
                        { userEnteredValue: { stringValue: 'Mã SP' } },
                        { userEnteredValue: { stringValue: 'Tên Sản Phẩm' } },
                        { userEnteredValue: { stringValue: 'Đơn Vị Tính' } },
                        { userEnteredValue: { stringValue: 'Số Lượng' } },
                        { userEnteredValue: { stringValue: 'Đơn Giá' } },
                        { userEnteredValue: { stringValue: 'Thành Tiền' } },
                        { userEnteredValue: { stringValue: 'Đối Tác / KH / NCC' } },
                        { userEnteredValue: { stringValue: 'Ghi Chú' } },
                      ],
                    },
                  ],
                },
              ],
            },
          ],
        },
      });

      const spreadsheetId = response.data.spreadsheetId;
      const spreadsheetUrl = response.data.spreadsheetUrl;

      res.json({
        success: true,
        spreadsheetId,
        spreadsheetUrl,
        message: 'Tạo Google Sheet thành công!',
      });
    } catch (error: any) {
      console.error('Error creating Google Sheet:', error);
      res.status(500).json({
        success: false,
        error: error.message || 'Không thể tạo Google Sheet. Vui lòng kiểm tra quyền xác thực OAuth.',
      });
    }
  });

  /**
   * Sync Up: Push Local App Data to Google Sheets
   */
  app.post('/api/sheets/sync-up', async (req, res) => {
    try {
      const { spreadsheetId, warehouses = [], products = [], transactions = [] } = req.body;

      if (!spreadsheetId) {
        return res.status(400).json({ success: false, error: 'Thiếu spreadsheetId' });
      }

      const auth = getGoogleAuth();
      const sheets = google.sheets({ version: 'v4', auth });

      // 1. Prepare DANH_MUC_KHO data
      const warehouseRows = [
        ['Mã Kho (*)', 'Tên Kho (*)', 'Địa Chỉ / Địa Điểm', 'Người Quản Lý', 'Số Điện Thoại'],
        ...warehouses.map((w: any) => [w.code, w.name, w.location || '', w.manager || '', w.phone || '']),
      ];

      // 2. Prepare DANH_MUC_SAN_PHAM data
      const productRows = [
        ['Mã Sản Phẩm (*)', 'Tên Sản Phẩm (*)', 'Đơn Vị Tính (*)', 'Nhóm Hàng', 'Tồn Tối Thiểu', 'Giá Nhập Tham Chiếu', 'Giá Xuất Tham Chiếu', 'Mô Tả'],
        ...products.map((p: any) => [p.code, p.name, p.unit, p.category || '', p.minStock || 0, p.costPrice || 0, p.sellingPrice || 0, p.description || '']),
      ];

      // 3. Prepare NHAP_XUAT_KHO data
      const transactionRows = [
        ['Mã Phiếu', 'Loại Phiếu (Nhập/Xuất)', 'Ngày (YYYY-MM-DD)', 'Mã Kho', 'Tên Kho', 'Mã SP', 'Tên Sản Phẩm', 'Đơn Vị Tính', 'Số Lượng', 'Đơn Giá', 'Thành Tiền', 'Đối Tác / KH / NCC', 'Ghi Chú'],
        ...transactions.map((t: any) => [
          t.voucherCode,
          t.type === 'IMPORT' ? 'Nhập' : 'Xuất',
          t.date,
          t.warehouseCode,
          t.warehouseName,
          t.productCode,
          t.productName,
          t.unit,
          t.quantity,
          t.unitPrice,
          t.totalAmount,
          t.partner || '',
          t.note || ''
        ]),
      ];

      // Clear & Update DANH_MUC_KHO
      await sheets.spreadsheets.values.clear({ spreadsheetId, range: 'DANH_MUC_KHO!A1:Z1000' });
      await sheets.spreadsheets.values.update({
        spreadsheetId,
        range: 'DANH_MUC_KHO!A1',
        valueInputOption: 'USER_ENTERED',
        requestBody: { values: warehouseRows },
      });

      // Clear & Update DANH_MUC_SAN_PHAM
      await sheets.spreadsheets.values.clear({ spreadsheetId, range: 'DANH_MUC_SAN_PHAM!A1:Z5000' });
      await sheets.spreadsheets.values.update({
        spreadsheetId,
        range: 'DANH_MUC_SAN_PHAM!A1',
        valueInputOption: 'USER_ENTERED',
        requestBody: { values: productRows },
      });

      // Clear & Update NHAP_XUAT_KHO
      await sheets.spreadsheets.values.clear({ spreadsheetId, range: 'NHAP_XUAT_KHO!A1:Z10000' });
      await sheets.spreadsheets.values.update({
        spreadsheetId,
        range: 'NHAP_XUAT_KHO!A1',
        valueInputOption: 'USER_ENTERED',
        requestBody: { values: transactionRows },
      });

      res.json({
        success: true,
        message: 'Đồng bộ dữ liệu lên Google Sheets thành công!',
        syncedAt: new Date().toISOString(),
      });
    } catch (error: any) {
      console.error('Error syncing up to Google Sheets:', error);
      res.status(500).json({
        success: false,
        error: error.message || 'Lỗi đồng bộ dữ liệu lên Google Sheets',
      });
    }
  });

  /**
   * Sync Down: Pull Data from Google Sheets to App
   */
  app.post('/api/sheets/sync-down', async (req, res) => {
    try {
      const { spreadsheetId } = req.body;

      if (!spreadsheetId) {
        return res.status(400).json({ success: false, error: 'Thiếu spreadsheetId' });
      }

      const auth = getGoogleAuth();
      const sheets = google.sheets({ version: 'v4', auth });

      // Fetch values from the 3 sheets
      const [whRes, prodRes, txRes] = await Promise.all([
        sheets.spreadsheets.values.get({ spreadsheetId, range: 'DANH_MUC_KHO!A2:E1000' }).catch(() => ({ data: { values: [] } })),
        sheets.spreadsheets.values.get({ spreadsheetId, range: 'DANH_MUC_SAN_PHAM!A2:H5000' }).catch(() => ({ data: { values: [] } })),
        sheets.spreadsheets.values.get({ spreadsheetId, range: 'NHAP_XUAT_KHO!A2:M10000' }).catch(() => ({ data: { values: [] } })),
      ]);

      const rawWh = whRes.data.values || [];
      const rawProd = prodRes.data.values || [];
      const rawTx = txRes.data.values || [];

      // Parse Warehouses
      const warehouses = rawWh
        .filter((r) => r[0] && r[1])
        .map((r, idx) => ({
          id: `wh-${r[0]}`.toLowerCase(),
          code: r[0],
          name: r[1],
          location: r[2] || '',
          manager: r[3] || '',
          phone: r[4] || '',
          isDefault: idx === 0,
        }));

      // Parse Products
      const products = rawProd
        .filter((r) => r[0] && r[1])
        .map((r) => ({
          id: `prod-${r[0]}`.toLowerCase(),
          code: r[0],
          name: r[1],
          unit: r[2] || 'Cái',
          category: r[3] || 'Khác',
          minStock: Number(r[4] || 0),
          costPrice: Number(r[5] || 0),
          sellingPrice: Number(r[6] || 0),
          description: r[7] || '',
        }));

      // Parse Transactions
      const transactions = rawTx
        .filter((r) => r[0] && r[3] && r[5])
        .map((r, idx) => {
          const typeStr = (r[1] || '').toString().toLowerCase();
          const isImport = typeStr.includes('nhập') || typeStr.includes('import');
          const wh = warehouses.find((w) => w.code === r[3]);
          const prod = products.find((p) => p.code === r[5]);

          return {
            id: `tx-${idx + 1}-${r[0]}`,
            voucherCode: r[0],
            type: isImport ? 'IMPORT' : 'EXPORT',
            date: r[2] || new Date().toISOString().split('T')[0],
            warehouseId: wh ? wh.id : `wh-${r[3]}`,
            warehouseCode: r[3],
            warehouseName: r[4] || (wh ? wh.name : r[3]),
            productId: prod ? prod.id : `prod-${r[5]}`,
            productCode: r[5],
            productName: r[6] || (prod ? prod.name : r[5]),
            unit: r[7] || (prod ? prod.unit : 'Cái'),
            quantity: Number(r[8] || 0),
            unitPrice: Number(r[9] || 0),
            totalAmount: Number(r[10] || 0) || Number(r[8] || 0) * Number(r[9] || 0),
            partner: r[11] || '',
            note: r[12] || '',
            createdAt: new Date().toISOString(),
          };
        });

      res.json({
        success: true,
        data: {
          warehouses,
          products,
          transactions,
        },
        syncedAt: new Date().toISOString(),
      });
    } catch (error: any) {
      console.error('Error syncing down from Google Sheets:', error);
      res.status(500).json({
        success: false,
        error: error.message || 'Lỗi đọc dữ liệu từ Google Sheets',
      });
    }
  });

  // Vite Integration
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
